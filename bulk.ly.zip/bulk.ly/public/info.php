<?php 


phpinfo();