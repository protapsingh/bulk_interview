<?php

namespace Bulkly;

use Illuminate\Database\Eloquent\Model;

class Plan extends Model
{
    //
}
